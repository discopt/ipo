#setup(ext_modules = cythonize(
#           "rect.pyx",                 # our Cython source
#           sources=["Rectangle.cpp"],  # additional source file(s)
#           language="c++",             # generate C++ code
#      ))
#clang C++

###################################
# setup.py, 1.0
# 14.10.2016, Sandra Hicks
#	generiert den gcc Command, um die Cython files zu kompilieren
#
###################################
from setuptools import setup, Extension
from Cython.Build import cythonize

extm = Extension(
    "MyMatrix",                 # name of extension
    ["Testproject/MyMatrix.pyx", "Testproject/Matrix.cpp"],           # filename of our Pyrex/Cython source
    language="c++"              # this causes Pyrex/Cython to create C++ source
    )
extv = Extension(
    "MyVector",                 # name of extension
    ["Testproject/MyVector.pyx", "Testproject/Vector.cpp"],           # filename of our Pyrex/Cython source
    language="c++"              # this causes Pyrex/Cython to create C++ source
    )

setup(name = 'MyLinAlg', version = '0.1',
    ext_modules = cythonize([extm, extv])
)
