###################################
# setup.py, 1.0
# 14.10.2016, Sandra Hicks
#	generiert den gcc Command, um die Cython files zu kompilieren
#
###################################
from setuptools import setup, Extension
from Cython.Build import cythonize

ext = Extension(
    "MyLinAlg",                 # name of extension
    ["Matrix.cpp", "Vector.cpp", "cVector.pxd", "cMatrix.pxd","cppIPOVector.pxd","MyLinAlg.pyx", "MyMatrix.pyx",  "MyVector.pyx", "IPOErrors.pyx", "IPOVector.pyx"],           # filename of our Pyrex/Cython source
    include_dirs = ["/usr/local/include/", "/opt/scipoptsuite-3.2.1/soplex-2.2.1/src", "/opt/scipoptsuite-3.2.1/scip-3.2.1/src"],

    libraries = ["ipo", "scipopt-3.2.1.linux.x86_64.gnu.opt", "soplex-2.2.1.linux.x86_64.gnu.opt", "scip-3.2.1.linux.x86_64.gnu.opt", "zimpl-3.3.3.linux.x86_64.gnu.opt", "nlpi.cppad.linux.x86_64.gnu.opt", "objscip-3.2.1.linux.x86_64.gnu.opt", "lpispx-3.2.1.linux.x86_64.gnu.opt", "gmp"],

    library_dirs = ["/usr/local/lib/", "/opt/scipoptsuite-3.2.1/lib/", "/opt/scipoptsuite-3.2.1/soplex-2.2.1/lib/", "/opt/scipoptsuite-3.2.1/scip-3.2.1/lib", "/opt/scipoptsuite-3.2.1/zimpl-3.3.3/lib"],
    runtime_library_dirs = ["/usr/local/lib/", "/opt/scipoptsuite-3.2.1/lib/", "/opt/scipoptsuite-3.2.1/soplex-2.2.1/lib/", "/opt/scipoptsuite-3.2.1/scip-3.2.1/lib", "/opt/scipoptsuite-3.2.1/zimpl-3.3.3/lib"],
    extra_compile_args=['-std=c++11', '-lz'],
    language="c++"              # this causes Pyrex/Cython to create C++ source
    )

setup(name = 'MyLinAlg', version = '0.1',
    ext_modules = cythonize([ext])
    #ext_modules = [ext]
)
