#include "Vector.h"

Vector::Vector(int length){
	this->m = length;
	initEntries();
}

void Vector::initEntries(){
	for(int i = 0; i < this->m; i++){
		this->entries.push_back(0);
	}
}

void Vector::multiply(vector<int> vec){
	printf("Multiply.\n");
}

void Vector::setEntry(int val, int row){
	printf("Set Entry %d at %d",val, row);
}
int Vector::getEntry(int row){
	return 0;
}
std::string Vector::getVector(){
	return "I am a Test!";
}
