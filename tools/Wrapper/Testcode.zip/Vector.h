#include <vector>
#include <string>
#include <cstdio>
using namespace std;

class Vector {
	private:
		std::vector<int> entries;
		int m;
		void initEntries();
	public:
		Vector(int m);
		void multiply(vector<int> vector);
		void setEntry(int val, int row);
		int getEntry(int row);
		std::string getVector();

		~Vector(){
			printf("Destructing Vector \n");
		}
};
