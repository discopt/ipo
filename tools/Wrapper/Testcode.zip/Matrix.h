#include <vector>
#include <string>
#include <cstdio>
#include <gmpxx.h>
using namespace std;

class Matrix {
	private:
		std::vector<int> entries;
		int m;
		int n;
		void initEntries();
	public:
		Matrix(int m, int n);
		void transpose();
		void setEntry(int val, int row, int col);
		int getEntry(int row, int col);
		std::string getMatrix();

		~Matrix(){
			printf("Destructing Matrix \n");
		}
};
