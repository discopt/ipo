#include "Matrix.h"
#include <gmpxx.h>
#include <soplex.h>
  #include <scip/scip.h>
  #include <scip/scipdefplugins.h>
  #include <scip/cons_linear.h>
  #include <ipo/scip_exception.hpp>
  #include <ipo/scip_oracles.h>
  #include <scip/debug.h>

Matrix::Matrix(int m, int n){
	this->m = m;
	this->n = n;
	initEntries();
}

void Matrix::initEntries(){
	for(int i = 0; i < (this->m * this->n); i++){
		this->entries.push_back(0);
	}
}

void Matrix::transpose(){
	printf("Transpose Matrix.\n");
	printf("gmp start\n");
        mpq_t s;
        mpq_init(s);
        mpq_clear(s);
        printf("gmp worked\n");
}

void Matrix::setEntry(int val, int row, int col){
	printf("rebuild test\n");
	printf("Set Entry %d at %d, %d\n",val, row, col);
}

int Matrix::getEntry(int row, int col){
	return 0;
}

std::string Matrix::getMatrix(){
	return "I am a Test!";
}
